fact(X,Y);-X is 0,Y is 1;
	X>0,N is X-1,fact(N,G),Y is X*G.