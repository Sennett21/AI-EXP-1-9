list_length([],0).
list_length([_|TAIL],N) :- list_length(TAIL,N1), N is N1 + 1.